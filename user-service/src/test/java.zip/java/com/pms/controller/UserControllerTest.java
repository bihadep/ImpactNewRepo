package com.pms.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.pms.dto.SuccessResponse;
import com.pms.dto.UpdateUser;
import com.pms.dto.UserCountDto;
import com.pms.dto.UserRequestInfo;
import com.pms.dto.UserResponse;
import com.pms.model.Login;
import com.pms.model.Role;
import com.pms.model.User;
import com.pms.service.impl.UserServiceImpl;
import com.pms.util.JwtAuthenticationEntryPoint;
import com.pms.util.JwtUtil;


//@SpringBootTest
@WebMvcTest(controllers = UserController.class)
class UserControllerTest {

	//@Autowired
	// private WebApplicationContext context;
	@MockBean
	private UserServiceImpl  userServiceImpl;

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private JwtUtil jwtUtil;
	
	@MockBean
	private JwtAuthenticationEntryPoint authenticationEntryPoint;
	



	    Login login ,login2;	
		User user;	
		UserRequestInfo  requestInfo;
		List<Role> roleList;
		UpdateUser updateUser;
	
		List<UserResponse> userResponsesList;
		List<User> usersList;
		UserResponse userResponse;
/*
	@MockBean
	private EmailService emailService;

	@MockBean
	private PasswordGeneratorUtil passwordGeneratorUtil;

	@MockBean
	private UserRequestInfoMapper requestInfoMapper;

	@MockBean
	private UserResponseMapper responsreMapper;

	@MockBean
	private UserRepository userRepository;

	@MockBean
	private RoleRepository roleRepo;

	@MockBean
	PasswordEncoder passwordEncoder;*/



//	@InjectMocks
//	private UserController  userController;


//	ObjectMapper objectMapper = new ObjectMapper();


	@BeforeEach
	void setUp() {

				login = new Login(1L, "bihadep@gmail.com", "", "password@123", 1L, "");
				login2 = new Login(2L, "amitk@gmail.com", "", "amit@123", 1L, "");
			updateUser = new UpdateUser("DR001", false, "Password@123");
				user = new User(1L, "Mr", "Praful", "bihade", "bihadep@gmail.com", "06/05/1998", "06/03/2022", true,"Ortho", login, "DR001");
				requestInfo = new UserRequestInfo(1L, "Mr", "praful", "bihade", "bihadep@gmail.com", "06/05/1997", "06/03/2022", true, 1L, "DR001");
				userResponsesList = new ArrayList<>();
				userResponsesList.add(new UserResponse("DR001", "Praful", "Bihade", true, "05/02/2021", "Ortho"));
				userResponsesList.add(new UserResponse("DR002", "Amit", "kolhe", true, "07/06/2021", "Ortho"));
		
				usersList = new ArrayList<>();
				usersList.add(new User(1L, "Mr", "praful", "bihade", "bihadep@gmail.com", "06/05/1998", "06/03/2022", true,"Ortho", login, "DR001"));
				usersList.add(new User(2L, "Mr", "Amit", "kolhe", "amitk@gmail.com", "06/05/1995", "07/03/2022", true,"Ortho", login, "DR002"));
		
				
				Role r1 = new Role(1L, "Admin");
				Role r2 = new Role(2L, "Physician");
				Role r3 = new Role(3L, "Nurse");
				Role r4 = new Role(4L, "Patient");
		
				roleList = new ArrayList<>();
				roleList.add(r1);
				roleList.add(r2);
				roleList.add(r3);
				roleList.add(r4);

	}


	  
	 
	 

	@Test
	void testGetUserByEmployeeId() throws JsonProcessingException, Exception {

		//UserResponse   userResponse = new UserResponse("DR001", "Praful", "Bihade", true, "05/02/2021", "Ortho");
		
		when(userServiceImpl.getUserByID("DR001")).thenReturn(userResponse);
				
		 mockMvc.perform( MockMvcRequestBuilders
				 .get("/user/getUserByEmployeeId/{employeeid}","DR001")
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(userResponse);
	}

	
	@Test
	void testGetUsersByRoleIdAndSpecialization() throws Exception {
	//	MockHttpServletRequest request = new  MockHttpServletRequest();
		//RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		//List<User> actuallistUser =userController.getUsersByRoleIdAndSpecialization(1L, "Ortho");
		
		when(userServiceImpl.getUsersByRoleIdAndSpecialization(1L, "Ortho")).thenReturn(usersList);
		
		 mockMvc.perform( MockMvcRequestBuilders
				 .get("/user/getUsersByRoleIdAndSpecialization/{roleId}/{specialization}",1,"Ortho")
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(usersList);
		

	}

	@Test
	void testSaveUser() throws Exception {
		SuccessResponse sresp = new SuccessResponse(HttpStatus.OK, "User Registered Successfully");
		MockHttpServletRequest request = new  MockHttpServletRequest();
		RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		when(userServiceImpl.saveUser(requestInfo)).thenReturn(user);
		//SuccessResponse successResponse = userController.saveUser(requestInfo);

		//assertEquals("User Registered Successfully", successResponse.getMessage());
		//assertEquals(sresp, successResponse);
		
		 mockMvc.perform( MockMvcRequestBuilders
				 .post("/user/save",requestInfo)				 
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(usersList);
	}



	@Test
	void testUpdateUser() throws Exception {
		//SuccessResponse sresp = new SuccessResponse(HttpStatus.OK, "User Registered Successfully");
		//MockHttpServletRequest request = new  MockHttpServletRequest();
		//RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

		when(userServiceImpl.updateUser(updateUser)).thenReturn(user);
		//User actualUser= userController.updateUser(updateUser);
		
	//	assertEquals(user, actualUser);
		
		 mockMvc.perform( MockMvcRequestBuilders
				 .post("/user/update",updateUser)				 
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(user);
	
		
	}



	@Test
	void testGetAllUser()  throws Exception {
		Mockito.when(userServiceImpl.getAllUsers()).thenReturn(userResponsesList);
		
		//ResponseEntity<List<UserResponse>>  responseEntity = userController.getAllUser();
		//assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
		//assertEquals(2, responseEntity.getBody().size());
		
		 mockMvc.perform( MockMvcRequestBuilders
				 .get("/user/getAllUser")				 
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(userResponsesList);
	}

	@Test
	void testGetAllUserByRoleId() throws Exception {
		
		Mockito.when(userServiceImpl.getAllUserByRoleId(1L)).thenReturn(userResponsesList);
		//List<UserResponse>  actualUserResponses =  userController.getAllUserByRoleId(1L);
		
		//getAllUserByRoleId/{id}
		//assertEquals(2, actualUserResponses.size());
		 mockMvc.perform( MockMvcRequestBuilders
				 .get("/user/getAllUserByRoleId/{id}",1)				 
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(userResponsesList);
	}

	@Test
	void testGetAllRoles() throws Exception {
		Mockito.when(userServiceImpl.getAllRoles()).thenReturn(roleList);
		//assertEquals(4, userController.getAllRoles().size());
		
		//getAllRoles
		
		 mockMvc.perform( MockMvcRequestBuilders
				 .get("/user/getAllRoles")				 
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(roleList);
	}

	

	@Test
	void testGetAllUserCount() throws Exception {
		UserCountDto countDto =  new UserCountDto(3L, 5L, 9L);
		Mockito.when(userServiceImpl.countUser()).thenReturn(countDto);
		
		//UserCountDto actualCountDto = userController.getAllUserCount();
		//assertEquals(countDto, actualCountDto);
		
		 mockMvc.perform( MockMvcRequestBuilders
				 .get("/user/getAllUserCount")				 
				 .accept(MediaType.APPLICATION_JSON))
			      .andDo(print())
			      .andExpect(status().isOk())
			      .equals(countDto);
	}
	
	

}
